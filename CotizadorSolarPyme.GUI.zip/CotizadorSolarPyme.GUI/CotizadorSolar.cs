﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace CotizadorSolarPyme.GUI
{
    internal class CotizadorSolar
    {
        public string NombrePyme { get; set; } = string.Empty;
        public int CantidadPaneles { get; set; }
        public double TarifaPanelUSD { get; set; }
        public double CostoInversoresUSD { get; set; }
        public bool AplicaFomentoEstatal { get; set; }
        public double PresupuestoMaximoUSD { get; set; }
        public double CalcularSubtotal()
        {
            double CostoTotalUSD = (CantidadPaneles * TarifaPanelUSD) + CostoInversoresUSD;
            return CostoTotalUSD;
        }
        public double CalcularMontoIva()
        {
            double MontoIvaUSD = CalcularSubtotal() * 0.19;
            return MontoIvaUSD;
        }
        public bool  EvaluarViabilidadEconomica()
        {
            if (PresupuestoMaximoUSD >= (CalcularSubtotal() + CalcularMontoIva()))
            {
                return true; // Viable
            }
            else
            {
                return false; // No viable
            }
        }
    }
}
