﻿namespace CotizadorSolarPyme.GUI
{
    partial class FormCotizador
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cboComuna = new ComboBox();
            grpResultados = new GroupBox();
            lblResSubtotal = new Label();
            lblSubtotal = new Label();
            btnSalir = new Button();
            btnLimpiar = new Button();
            txtPyme = new TextBox();
            lblPyme = new Label();
            gprCliente = new GroupBox();
            lblComuna = new Label();
            lblPaneles = new Label();
            txtPaneles = new TextBox();
            gprTecnico = new GroupBox();
            txtPresupuesto = new TextBox();
            lblPresupuesto = new Label();
            txtCostoInversor = new TextBox();
            lblInversor = new Label();
            txtTarifaPanel = new TextBox();
            lblTarifaPanel = new Label();
            chkFomento = new CheckBox();
            grpResultados.SuspendLayout();
            gprCliente.SuspendLayout();
            gprTecnico.SuspendLayout();
            SuspendLayout();
            // 
            // cboComuna
            // 
            cboComuna.FormattingEnabled = true;
            cboComuna.Location = new Point(99, 45);
            cboComuna.Name = "cboComuna";
            cboComuna.Size = new Size(121, 23);
            cboComuna.TabIndex = 0;
            // 
            // grpResultados
            // 
            grpResultados.Controls.Add(lblResSubtotal);
            grpResultados.Controls.Add(lblSubtotal);
            grpResultados.Location = new Point(52, 346);
            grpResultados.Name = "grpResultados";
            grpResultados.Size = new Size(682, 181);
            grpResultados.TabIndex = 1;
            grpResultados.TabStop = false;
            // 
            // lblResSubtotal
            // 
            lblResSubtotal.Location = new Point(96, 21);
            lblResSubtotal.Name = "lblResSubtotal";
            lblResSubtotal.Size = new Size(312, 20);
            lblResSubtotal.TabIndex = 2;
            // 
            // lblSubtotal
            // 
            lblSubtotal.AutoSize = true;
            lblSubtotal.Location = new Point(40, 21);
            lblSubtotal.Name = "lblSubtotal";
            lblSubtotal.Size = new Size(51, 15);
            lblSubtotal.TabIndex = 0;
            lblSubtotal.Text = "Subtotal";
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(691, 174);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(75, 23);
            btnSalir.TabIndex = 2;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(691, 144);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(75, 23);
            btnLimpiar.TabIndex = 3;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // txtPyme
            // 
            txtPyme.Location = new Point(99, 16);
            txtPyme.Name = "txtPyme";
            txtPyme.Size = new Size(302, 23);
            txtPyme.TabIndex = 4;
            txtPyme.Leave += txtPyme_Leave;
            // 
            // lblPyme
            // 
            lblPyme.AutoSize = true;
            lblPyme.Location = new Point(21, 19);
            lblPyme.Name = "lblPyme";
            lblPyme.Size = new Size(40, 15);
            lblPyme.TabIndex = 5;
            lblPyme.Text = "Pyme:";
            // 
            // gprCliente
            // 
            gprCliente.Controls.Add(lblComuna);
            gprCliente.Controls.Add(lblPyme);
            gprCliente.Controls.Add(txtPyme);
            gprCliente.Controls.Add(cboComuna);
            gprCliente.Location = new Point(59, 21);
            gprCliente.Name = "gprCliente";
            gprCliente.Size = new Size(546, 100);
            gprCliente.TabIndex = 6;
            gprCliente.TabStop = false;
            gprCliente.Text = "Cliente";
            // 
            // lblComuna
            // 
            lblComuna.AutoSize = true;
            lblComuna.Location = new Point(21, 53);
            lblComuna.Name = "lblComuna";
            lblComuna.Size = new Size(56, 15);
            lblComuna.TabIndex = 6;
            lblComuna.Text = "Comuna:";
            // 
            // lblPaneles
            // 
            lblPaneles.AutoSize = true;
            lblPaneles.Location = new Point(10, 22);
            lblPaneles.Name = "lblPaneles";
            lblPaneles.Size = new Size(50, 15);
            lblPaneles.TabIndex = 8;
            lblPaneles.Text = "Paneles:";
            // 
            // txtPaneles
            // 
            txtPaneles.Location = new Point(99, 14);
            txtPaneles.Name = "txtPaneles";
            txtPaneles.Size = new Size(302, 23);
            txtPaneles.TabIndex = 7;
            txtPaneles.Leave += txtPaneles_Leave;
            // 
            // gprTecnico
            // 
            gprTecnico.Controls.Add(txtPresupuesto);
            gprTecnico.Controls.Add(lblPresupuesto);
            gprTecnico.Controls.Add(txtCostoInversor);
            gprTecnico.Controls.Add(lblInversor);
            gprTecnico.Controls.Add(txtTarifaPanel);
            gprTecnico.Controls.Add(lblTarifaPanel);
            gprTecnico.Controls.Add(txtPaneles);
            gprTecnico.Controls.Add(lblPaneles);
            gprTecnico.Location = new Point(59, 156);
            gprTecnico.Name = "gprTecnico";
            gprTecnico.Size = new Size(546, 147);
            gprTecnico.TabIndex = 7;
            gprTecnico.TabStop = false;
            gprTecnico.Text = "Especificaciones Técnicas";
            // 
            // txtPresupuesto
            // 
            txtPresupuesto.Location = new Point(99, 105);
            txtPresupuesto.Name = "txtPresupuesto";
            txtPresupuesto.Size = new Size(302, 23);
            txtPresupuesto.TabIndex = 14;
            // 
            // lblPresupuesto
            // 
            lblPresupuesto.AutoSize = true;
            lblPresupuesto.Location = new Point(10, 108);
            lblPresupuesto.Name = "lblPresupuesto";
            lblPresupuesto.Size = new Size(75, 15);
            lblPresupuesto.TabIndex = 13;
            lblPresupuesto.Text = "Presupuesto:";
            // 
            // txtCostoInversor
            // 
            txtCostoInversor.Location = new Point(99, 76);
            txtCostoInversor.Name = "txtCostoInversor";
            txtCostoInversor.Size = new Size(302, 23);
            txtCostoInversor.TabIndex = 12;
            // 
            // lblInversor
            // 
            lblInversor.AutoSize = true;
            lblInversor.Location = new Point(10, 79);
            lblInversor.Name = "lblInversor";
            lblInversor.Size = new Size(86, 15);
            lblInversor.TabIndex = 11;
            lblInversor.Text = "Costo inversor:";
            // 
            // txtTarifaPanel
            // 
            txtTarifaPanel.Location = new Point(99, 43);
            txtTarifaPanel.Name = "txtTarifaPanel";
            txtTarifaPanel.Size = new Size(302, 23);
            txtTarifaPanel.TabIndex = 9;
            txtTarifaPanel.Leave += txtTarifaPanel_Leave;
            // 
            // lblTarifaPanel
            // 
            lblTarifaPanel.AutoSize = true;
            lblTarifaPanel.Location = new Point(10, 51);
            lblTarifaPanel.Name = "lblTarifaPanel";
            lblTarifaPanel.Size = new Size(70, 15);
            lblTarifaPanel.TabIndex = 10;
            lblTarifaPanel.Text = "Tarifa Panel:";
            // 
            // chkFomento
            // 
            chkFomento.AutoSize = true;
            chkFomento.Location = new Point(69, 309);
            chkFomento.Name = "chkFomento";
            chkFomento.Size = new Size(74, 19);
            chkFomento.TabIndex = 8;
            chkFomento.Text = "Fomento";
            chkFomento.TextAlign = ContentAlignment.TopRight;
            chkFomento.UseVisualStyleBackColor = true;
            // 
            // FormCotizador
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 569);
            Controls.Add(chkFomento);
            Controls.Add(gprTecnico);
            Controls.Add(gprCliente);
            Controls.Add(btnLimpiar);
            Controls.Add(btnSalir);
            Controls.Add(grpResultados);
            Name = "FormCotizador";
            Tag = "|";
            Text = "         ";
            Load += FormCotizador_Load;
            grpResultados.ResumeLayout(false);
            grpResultados.PerformLayout();
            gprCliente.ResumeLayout(false);
            gprCliente.PerformLayout();
            gprTecnico.ResumeLayout(false);
            gprTecnico.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cboComuna;
        private GroupBox grpResultados;
        private Button btnSalir;
        private Button btnLimpiar;
        private TextBox txtPyme;
        private Label lblPyme;
        private GroupBox gprCliente;
        private Label lblComuna;
        private Label lblPaneles;
        private TextBox txtPaneles;
        private GroupBox gprTecnico;
        private TextBox txtTarifaPanel;
        private Label lblTarifaPanel;
        private TextBox txtCostoInversor;
        private Label lblInversor;
        private CheckBox chkFomento;
        private TextBox txtPresupuesto;
        private Label lblPresupuesto;
        private Label lblSubtotal;
        private Label lblResSubtotal;
    }
}
