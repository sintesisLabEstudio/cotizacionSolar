using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace CotizadorSolarPyme.GUI
{
    public partial class FormCotizador : Form
    {
        public FormCotizador()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Evento Load del Formulario: Configura el entorno regional invariable
        /// y puebla dinámicamente el ComboBox de comunas de la Región del Biobío.
        /// </summary>
        private void FormCotizador_Load(object sender, EventArgs e)
        {
            // Configurar cultura decimal global invariable
            CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;

            // Poblar ComboBox de Comunas si está vacío
            if (cboComuna.Items.Count == 0)
            {
                cboComuna.Items.Add("Concepción");
                cboComuna.Items.Add("Talcahuano");
                cboComuna.Items.Add("San Pedro de la Paz");
                cboComuna.Items.Add("Chiguayante");
                cboComuna.Items.Add("Coronel");
                cboComuna.Items.Add("Lota");
                cboComuna.Items.Add("Los Ángeles");
                cboComuna.Items.Add("Chillán");
            }

            cboComuna.SelectedIndex = 0;
            grpResultados.Enabled = false;
        }

        /// <summary>
        /// Manejador del Evento Click del Botón Salir:
        /// Solicita confirmación visual antes de cerrar la aplicación.
        /// </summary>
        private void btnSalir_Click(object sender, EventArgs e)
        {
            DialogResult respuesta = MessageBox.Show(
                "¿Está seguro de que desea salir del Cotizador Solar de PYMES?",
                "Confirmación de Salida",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (respuesta == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        /// <summary>
        /// Manejador del Evento Click del Botón Limpiar:
        /// Restablece todos los campos del formulario a su estado inicial.
        /// </summary>
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarFormulario();
        }

        /// <summary>
        /// Restablece el estado visual de los controles de la interfaz.
        /// </summary>
        private void LimpiarFormulario()
        {
            txtPyme.Clear();
            if (cboComuna.Items.Count > 0)
            {
                cboComuna.SelectedIndex = 0;
            }
            txtPaneles.Clear();
            txtTarifaPanel.Clear();
            txtCostoInversor.Clear();
            chkFomento.Checked = false;
            txtPresupuesto.Clear();

            // Restablecer etiquetas de salida en el GroupBox de resultados
            lblResSubtotal.Text = "$ 0.00 USD";
            //lblResDescuento.Text = "$ 0.00 USD";
            //lblResIva.Text = "$ 0.00 USD";
            //lblResTotal.Text = "$ 0.00 USD";
            //lblResViabilidad.Text = "PENDIENTE";
            //lblResViabilidad.ForeColor = Color.DarkGray;

            grpResultados.Enabled = false;
            txtPyme.Focus();
        }

        /// <summary>
        /// Valida las entradas de texto del usuario emitiendo cuadros de diálogo MessageBox
        /// en caso de detectar valores vacíos o formatos incorrectos.
        /// </summary>
        private bool ValidarEntradasIniciales(out int paneles, out double tarifaPanel, out double costoInversor, out double presupuesto)
        {
            paneles = 0;
            tarifaPanel = 0.0;
            costoInversor = 0.0;
            presupuesto = 0.0;

            // 1. Validar Nombre de la PYME
            if (string.IsNullOrWhiteSpace(txtPyme.Text))
            {
                MessageBox.Show(
                    "Por favor, ingrese el nombre de la PYME cliente.",
                    "Campo Requerido",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtPyme.Focus();
                return false;
            }

            // 2. Validar Cantidad de Paneles (Entero entre 1 y 200)
            if (!int.TryParse(txtPaneles.Text, out paneles) || paneles < 1 || paneles > 200)
            {
                MessageBox.Show(
                    "Ingrese una cantidad entera válida de paneles solares (entre 1 y 200).",
                    "Error de Formato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtPaneles.SelectAll();
                txtPaneles.Focus();
                return false;
            }

            // 3. Validar Tarifa por Panel (Decimal entre 50 y 2000 USD)
            if (!double.TryParse(txtTarifaPanel.Text, out tarifaPanel) || tarifaPanel < 50.0 || tarifaPanel > 2000.0)
            {
                MessageBox.Show(
                    "Ingrese un costo unitario por panel válido ($ USD entre 50.00 y 2000.00).",
                    "Error de Formato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtTarifaPanel.SelectAll();
                txtTarifaPanel.Focus();
                return false;
            }

            // 4. Validar Costo de Inversores (Decimal entre 100 y 10000 USD)
            if (!double.TryParse(txtCostoInversor.Text, out costoInversor) || costoInversor < 100.0 || costoInversor > 10000.0)
            {
                MessageBox.Show(
                    "Ingrese un costo de inversores y montaje válido ($ USD entre 100.00 y 10000.00).",
                    "Error de Formato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtCostoInversor.SelectAll();
                txtCostoInversor.Focus();
                return false;
            }

            // 5. Validar Presupuesto del Cliente (Decimal entre 500 y 1000000 USD)
            if (!double.TryParse(txtPresupuesto.Text, out presupuesto) || presupuesto < 500.0 || presupuesto > 1000000.0)
            {
                MessageBox.Show(
                    "Ingrese un presupuesto máximo disponible válido ($ USD entre 500.00 y 1000000.00).",
                    "Error de Formato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtPresupuesto.SelectAll();
                txtPresupuesto.Focus();
                return false;
            }

            return true;
        }

        private void txtPyme_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPyme.Text))
            {
                MessageBox.Show(
                    "El nombre de la PYME no puede estar vacío.",
                    "Campo Requerido",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtPyme.Focus();
            }
        }

        private void txtPaneles_Leave(object sender, EventArgs e)
        {
            if (!int.TryParse(txtPaneles.Text, out int paneles) || paneles < 1 || paneles > 200)
            {
                MessageBox.Show(
                    "Ingrese una cantidad entera válida de paneles solares (entre 1 y 200).",
                    "Error de Formato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtPaneles.SelectAll();
                txtPaneles.Focus();
            }
        }

        private void txtTarifaPanel_Leave(object sender, EventArgs e)
        {
            if(!double.TryParse(txtTarifaPanel.Text, out double tarifaPanel) || tarifaPanel < 50.0 || tarifaPanel > 2000.0)
            {
                MessageBox.Show(
                    "Ingrese un costo unitario por panel válido ($ USD entre 50.00 y 2000.00).",
                    "Error de Formato",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                txtTarifaPanel.SelectAll();
                txtTarifaPanel.Focus();
            }
        }
    }
}
